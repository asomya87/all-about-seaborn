#!/usr/bin/env python
# coding: utf-8

# # Heatmap using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

#creating an array using numpy library through linspace function

var=np.linspace(1,10,20).reshape(4,5)

var


# In[2]:


sns.heatmap(var)

plt.show()


# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

#using external dataset

sns.get_dataset_names()


# In[8]:


data = sns.load_dataset('anagrams')


# In[9]:


data


# In[11]:


data = sns.load_dataset('anagrams')
x = data.drop(columns=["attnr"], axis=1)

x


# In[13]:


sns.heatmap(x)

plt.show()


# In[21]:


data = sns.load_dataset('anagrams').head(10)
x = data.drop(columns=["attnr"], axis=1)
sns.heatmap(x, vmin=0, vmax=12, cmap='PuOr', annot=True)

plt.show()


# In[23]:


var1=np.linspace(1,10,10).reshape(2,5)

var1


# In[24]:


sns.heatmap(var1, vmin=0, vmax=12, cmap='PuOr', annot=True)

plt.show()


# In[30]:


#creating a new array

ar = np.array([["a0","a1","a2","a3","a4"],
               ["b0","b1","b2","b3","b4"]])
               
ar


# In[36]:


y={"fontsize":20, "color":'r'}
sns.heatmap(var1, vmin=0, vmax=12, cmap='PuOr', annot=ar,fmt='s', annot_kws=y, linewidth=20, 
            linecolor='k', cbar=False, xticklabels=False, yticklabels=False)

plt.show()


# In[39]:


y={"fontsize":20, "color":'r'}
v = sns.heatmap(var1, vmin=0, vmax=12, cmap='PuOr', annot=ar,fmt='s', annot_kws=y, linewidth=20, 
            linecolor='k', cbar=False, xticklabels=False, yticklabels=False)
v.set(xlabel='X-axis', ylabel='Y-axis')
sns.set(font_scale=5)

plt.show()


# In[ ]:




