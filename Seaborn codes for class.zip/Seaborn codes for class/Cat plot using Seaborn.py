#!/usr/bin/env python
# coding: utf-8

# # Cat plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[9]:


sns.catplot(x='day', y='size', data=var, hue='sex', palette='Oranges', kind='bar')

plt.show()


# In[11]:


sns.catplot(x='day', y='size', data=var, hue='sex', palette='Oranges', kind='point')

plt.show()


# In[ ]:




