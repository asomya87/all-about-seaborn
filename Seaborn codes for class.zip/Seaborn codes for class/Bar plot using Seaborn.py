#!/usr/bin/env python
# coding: utf-8

# # Bar plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("penguins")
var


# In[2]:


#option 1 of writing

sns.barplot(x=var.island, y=var.bill_length_mm)

plt.show()


# In[3]:


#option 2 of writing

sns.barplot(x='island', y='bill_length_mm', data=var)

plt.show()


# In[10]:


order_1 = ["Dream", "Biscoe", "Torgersen"]

sns.barplot(x='island', y='bill_length_mm', data=var, hue='sex', order=order_1, hue_order=["Female", "Male"])

plt.show()


# In[14]:


order_1 = ["Dream", "Biscoe", "Torgersen"]

sns.barplot(x='bill_depth_mm', y='bill_length_mm', data=var, orient='v')

plt.show()


# In[15]:


sns.barplot(x='island', y='bill_length_mm', data=var, color='r')

plt.show()


# In[19]:


order_1 = ["Dream", "Biscoe", "Torgersen"]

sns.barplot(x='island', y='bill_length_mm', data=var, hue='sex', order=order_1, hue_order=["Female", "Male"], 
            palette='Accent')

plt.show()


# In[26]:


sns.set(style='dark')
order_1 = ["Dream", "Biscoe", "Torgersen"]

sns.barplot(x='island', y='bill_length_mm', data=var, hue='sex', order=order_1, hue_order=["Female", "Male"], 
            errcolor='g')

plt.show()


# In[ ]:




