#!/usr/bin/env python
# coding: utf-8

# # Scatter plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("penguins")
var


# In[4]:


sns.scatterplot(x="bill_length_mm", y="bill_depth_mm", data=var, hue='sex')

plt.show()


# In[5]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("penguins").head(20)
var


# In[14]:


m={"Male":"*", "Female":"o"}
sns.scatterplot(x="bill_length_mm", y="bill_depth_mm", data=var, hue='sex', style='sex', 
                size='sex', sizes =(100,200), palette='Accent', alpha=1, markers=m)

plt.show()


# In[ ]:




