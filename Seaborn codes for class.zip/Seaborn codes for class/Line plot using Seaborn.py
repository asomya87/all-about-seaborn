#!/usr/bin/env python
# coding: utf-8

# # Line plot using Seaborn 

# In[1]:


get_ipython().system('pip install matplotlib')


# In[2]:


get_ipython().system('pip install seaborn')


# In[3]:


import matplotlib.pyplot as plt
import seaborn as sns

var = [1,2,3,4,5,6,7]
var_1 = [3,4,5,6,7,1,2]

plt.plot(var,var_1)
plt.show()


# In[6]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = [1,2,3,4,5,6,7]
var_1 = [3,4,5,6,7,1,2]

#creating a dataframe
x_1 = pd.DataFrame({"var":var, "var_1":var_1})

sns.lineplot(x='var', y='var_1', data=x_1) #data stores the data that comes from the dataframe

plt.show()


# In[7]:


#code without using a dataframe

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = [1,2,3,4,5,6,7]
var_1 = [3,4,5,6,7,1,2]

sns.lineplot(x=var, y=var_1) 

plt.show()


# In[16]:


y_1 = sns.load_dataset("penguins").head(20)
y_1 #to view the dataset


# In[19]:


sns.lineplot(x='bill_length_mm', y='bill_depth_mm', data=y_1, hue='sex', style='sex', palette='Accent', 
             markers=["o", ">"], dashes=False, legend=False) 

plt.show()


# In[21]:


sns.lineplot(x='bill_length_mm', y='bill_depth_mm', data=y_1, hue='sex', style='sex', palette='Accent', 
             markers=["o", ">"], dashes=False, legend="full") 

plt.grid()
plt.title("Penguins data", fontsize=20)

plt.show()


# In[ ]:




