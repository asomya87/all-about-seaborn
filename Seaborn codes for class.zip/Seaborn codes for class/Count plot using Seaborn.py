#!/usr/bin/env python
# coding: utf-8

# # Count plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[6]:


sns.countplot(x="sex", data=var, hue='smoker')

plt.show()


# In[8]:


sns.countplot(x="sex", data=var, hue='smoker', palette='rocket_r')

plt.show()


# In[9]:


sns.countplot(x="sex", data=var, hue='smoker', palette='rocket_r', saturation=0.6)

plt.show()


# In[7]:


#horizontal plot

sns.countplot(y="sex", data=var, hue='smoker')

plt.show()


# In[5]:


#using barplot

sns.barplot(x='sex', y="size", data=var)

plt.show()


# In[ ]:




