#!/usr/bin/env python
# coding: utf-8

# # Strip plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[15]:


sns.stripplot(x='day', y='total_bill', data=var, 
hue='sex', palette='rocket_r', linewidth=1, edgecolor='r', jitter=5, size=10, marker='*')

plt.show()


# In[17]:


sns.stripplot(x=var['total_bill'])

plt.show()


# In[18]:


sns.stripplot(y=var['total_bill'])

plt.show()


# In[ ]:




