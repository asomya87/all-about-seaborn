#!/usr/bin/env python
# coding: utf-8

# In[ ]:


Violin plot using Seaborn


# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[4]:


sns.violinplot(x='day', y='total_bill', data = var, hue='time')

plt.show()


# In[6]:


sns.violinplot(x='day', y='total_bill', data = var, linewidth=3, palette='Accent')

plt.show()


# In[9]:


sns.violinplot(x='time', y='tip', data = var, linewidth=3, order=["Lunch","Dinner"])

plt.show()


# In[10]:


sns.violinplot(x='day', y='total_bill', data = var, linewidth=3, color='g')

plt.show()


# In[12]:


sns.violinplot(x='day', y='total_bill', data = var, hue='sex', split=True, scale="width")

plt.show()


# In[13]:


#horizontal plot

sns.violinplot(x='total_bill', y='day', data = var, hue='sex', split=True, scale="width")

plt.show()


# In[14]:


sns.violinplot(x='day', y='total_bill', data = var, hue='sex', split=True, scale="width", inner='quart')

plt.show()


# In[15]:


#single plot horizontally

sns.violinplot(x=var['total_bill'])

plt.show()


# In[16]:


#single plot vertically

sns.violinplot(y=var['total_bill'])

plt.show()


# In[ ]:




