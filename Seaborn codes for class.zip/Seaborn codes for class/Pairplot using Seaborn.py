#!/usr/bin/env python
# coding: utf-8

# # Pairplot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[3]:


sns.pairplot(var, hue='sex')

plt.show()


# In[6]:


sns.pairplot(var, vars=["total_bill", "tip"], hue='sex')

plt.show()


# In[9]:


sns.pairplot(var, vars=["total_bill", "tip"], hue='sex', hue_order=["Female", "Male"], palette='BuGn')

plt.show()


# In[10]:


sns.pairplot(var, hue='sex', hue_order=["Female", "Male"], x_vars=["total_bill", "tip"])

plt.show()


# In[11]:


sns.pairplot(var, hue='sex', hue_order=["Female", "Male"], y_vars=["total_bill", "tip"])

plt.show()


# In[12]:


sns.pairplot(var, hue='sex', hue_order=["Female", "Male"], kind="reg")

plt.show()

#We can also pass 'scatter', 'kde', 'hist' in kind


# In[14]:


sns.pairplot(var, hue='sex', hue_order=["Female", "Male"], kind="kde", diag_kind='hist')

plt.show()

#We can also pass 'scatter', 'kde', 'hist' in kind


# In[15]:


sns.pairplot(var, hue='sex', hue_order=["Female", "Male"], markers=['*', '<'])

plt.show()


# In[ ]:




