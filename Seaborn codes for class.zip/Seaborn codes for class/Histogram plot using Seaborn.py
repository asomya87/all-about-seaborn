#!/usr/bin/env python
# coding: utf-8

# # Histogram plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("penguins")

var


# In[7]:


sns.displot(var["bill_length_mm"])

plt.show()


# In[14]:


sns.displot(var["flipper_length_mm"], bins=[170,180,190,200,210,220,230,240], kde=True, rug=True, color='r')

plt.show()


# In[16]:


sns.displot(var["flipper_length_mm"], kde=True, rug=True, color='r', log_scale=True)

plt.show()


# In[ ]:




