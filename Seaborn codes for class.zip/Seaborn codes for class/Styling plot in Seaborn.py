#!/usr/bin/env python
# coding: utf-8

# # Styling plot in Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[3]:


sns.boxplot(y=var["total_bill"])

plt.show()


# In[6]:


sns.barplot(x='day', y='total_bill', data=var)

plt.grid()

plt.show()


# In[7]:


sns.set_style("darkgrid")

sns.barplot(x='day', y='total_bill', data=var)

plt.show()


# In[8]:


sns.set_style("ticks")

sns.barplot(x='day', y='total_bill', data=var)

plt.show()


# In[9]:


sns.set_style("whitegrid")

sns.barplot(x='day', y='total_bill', data=var)

sns.despine()

plt.show()


# In[17]:


sns.set_style("whitegrid")

plt.figure(figsize=(12,3))

sns.barplot(x='day', y='total_bill', data=var)

sns.despine()

plt.show()


# In[14]:


sns.set_style("white")

sns.set_context("poster", font_scale=0.2)

sns.barplot(x='day', y='total_bill', data=var)

sns.despine()

plt.show()


# In[16]:


sns.set_style("white")

sns.set_context("paper", font_scale=1)

sns.barplot(x='day', y='total_bill', data=var)

sns.despine()

plt.show()


# In[ ]:




