#!/usr/bin/env python
# coding: utf-8

# # Box plot using Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[2]:


sns.set(style="whitegrid")


# In[21]:


sns.boxplot(x='day', y='total_bill', data=var, hue='sex', color='r', order=['Fri', 'Sun', 'Thur', 'Sat'], 
           showmeans=True, meanprops={"marker":"+", "markeredgecolor":'g'}, linewidth=3,
           palette='flare', orient='v')

#for the orientation to be horizontal, the variable in X-axis should be categorical and 
#the variable in Y-axis should be numerical always
plt.show()


# In[23]:


sns.boxplot(x='total_bill', y='day', data=var, hue='sex', color='r', order=['Fri', 'Sun', 'Thur', 'Sat'], 
           showmeans=True, meanprops={"marker":"+", "markeredgecolor":'g'}, linewidth=3,
           palette='flare')

plt.show()


# In[25]:


sns.boxplot(data=var, showmeans=True, meanprops={"marker":"+", "markeredgecolor":'g'}, linewidth=3,
           palette='flare', orient='h')

plt.show()


# In[26]:


sns.boxplot(x=var["total_bill"] )

plt.show()


# In[27]:


sns.boxplot(y=var["total_bill"] )

plt.show()


# In[ ]:




