#!/usr/bin/env python
# coding: utf-8

# # Facet grid in Seaborn

# In[1]:


import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

var = sns.load_dataset("tips")

var


# In[5]:


fg = sns.FacetGrid(var, col='sex', hue='day')

fg.map(plt.scatter, "total_bill", "tip").add_legend()

plt.show()


# In[6]:


fg = sns.FacetGrid(var, col='day', hue='sex')

fg.map(plt.scatter, "total_bill", "tip").add_legend()

plt.show()


# In[7]:


fg = sns.FacetGrid(var, col='day', hue='sex')

fg.map(plt.bar, "total_bill", "tip").add_legend()

plt.show()


# In[12]:


fg = sns.FacetGrid(var, col='sex', hue='day', palette='summer')

fg.map(plt.bar, "total_bill", "tip", edgecolor='r').add_legend()

plt.show()


# In[ ]:




